//
//  APICommonParamsGenerator.h
//  LESports
//
//  Created by ZhangQibin on 15/6/22.
//  Copyright (c) 2015年 LETV. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface APICommonParamsGenerator : NSObject

+ (NSDictionary *)commonParamsDictionary;

@end
